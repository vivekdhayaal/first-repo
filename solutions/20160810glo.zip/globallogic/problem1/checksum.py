from sys import argv

def checksum(filename):
  with open(filename) as f:
    return sum(map(ord, f.read()))

if __name__ == '__main__':
  print checksum(argv[1])
