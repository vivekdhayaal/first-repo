from sys import argv
filename = argv[1]
with open(filename) as f:
  lines = f.readlines()
  # calculate length only once as all lines have same no.of words
  wordLen = len(lines[0].split())
  only1stWordDiffLines = []
  for i in xrange(len(lines)-1):
    currLine = lines[i]
    nextLine = lines[i+1]
    currLineWords = currLine.split()
    nextLineWords = nextLine.split()
    if currLineWords[0].lower() != nextLineWords[0].lower():
      mismatch = False
      for j in xrange(1, wordLen):
        if currLineWords[j].strip().lower() != nextLineWords[j].strip().lower():
          mismatch = True
          break
      if not mismatch:
        only1stWordDiffLines.append((currLine, nextLine))
print only1stWordDiffLines
