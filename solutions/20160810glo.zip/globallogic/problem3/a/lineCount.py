from sys import argv
filename = argv[1]
with open(filename) as f:
  lineCount = {}
  for line in f.xreadlines():
    try:
      lineCount[line.strip()] += 1
    except KeyError:
      lineCount[line.strip()] = 1
print lineCount
