from sys import argv
filename = argv[1]
with open(filename) as f:
  lines = f.readlines()
  # calculate length only once as all lines have same no.of words
  wordLen = len(lines[0].split())
  offBy1Lines = []
  for i in xrange(len(lines)-1):
    if i == len(lines) - 2:
      import pdb;pdb.set_trace()
    currLine = lines[i]
    currLineWords = currLine.split()
    #for j in xrange(lines.length(), i+1):
    #  nextLineWords = lines[j].split()
    nextLine = lines[i+1]
    nextLineWords = nextLine.split()
    mismatchCount = 0
    mismatchIndices = []
    for k in xrange(wordLen):
      if currLineWords[k].lower() != nextLineWords[k].lower():
        mismatchCount += 1
        mismatchIndices.append(k)
        if mismatchCount > 2:
          break
    if mismatchCount > 2:
      continue
    elif mismatchCount == 2:
      index1 = mismatchIndices[0]
      index2 = mismatchIndices[1]
      if (index2 - index1) == 1:
        if currLineWords[index1].strip().strip('.').lower() == nextLineWords[index2].strip().strip('.').lower():
          if currLineWords[index2].strip().strip('.').lower() == nextLineWords[index1].strip().strip('.').lower():
            #if currLine not in offBy1Lines:
            offBy1Lines.append(currLine)
            #if nextLine not in offBy1Lines:
            offBy1Lines.append(nextLine)
with open('offBy1Lines.txt', 'w') as f:
  f.writelines(offBy1Lines)
