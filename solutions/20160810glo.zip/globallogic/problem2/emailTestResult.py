from sys import argv
from smtplib import SMTP
import os

def send_email_from_gmail(user, pwd, to, subject, body):
  msg = "From: %s\nTo: %s\nSubject: %s\n%s" % (user, ", ".join(to), subject, body)
  try:
    server = SMTP("smtp.gmail.com", 587)
    server.ehlo()
    server.starttls()
    server.login(user, pwd)
    server.sendmail(user, to, msg)
    server.close()
  except:
    print "email send failure"

results = {'pass' : 0, 'fail' : 0}
with open(os.path.join(os.path.dirname(__file__), "test-result/result-file.csv")) as f:
  lines = f.readlines()
  # sample file format
  # TEST_CASE,RESULT
  # testcase1,pass
  # testcase2,fail
  # ...
  for i in xrange(1, len(lines)):
    testname, result = lines[i].split(',')
    results[result.strip()] += 1
totalTests = results['pass'] + results['fail']
passpercent = (float(results['pass'])/totalTests) * 100
failpercent = (float(results['fail'])/totalTests) * 100
msg = """
Test Summary:
Pass percent = %s
Fail percent = %s
""" % (passpercent, failpercent)
print results
print msg
    
#send_email_from_gmail("abc@gmail.com", "password", ["xyz@globallogic.com"], "Test status report", msg)
